# RAG Document QA

A Retrieval-Augmented Generation (RAG) system that answers questions about your own documents. Instead of relying only on what a language model memorised in training, it first retrieves relevant passages from your files and asks the model to answer using only that text, then shows which sources it used.

## How it works

```
Documents (PDF/TXT/MD)
   -> split into overlapping chunks      (RecursiveCharacterTextSplitter, 1000 chars / 200 overlap)
   -> embed each chunk                   (sentence-transformers all-MiniLM-L6-v2, 384-dim)
   -> store vectors in a FAISS index

Question
   -> embed -> retrieve top-k similar chunks
   -> prompt: "answer ONLY from this context" + question
   -> LLM answer + source list
```

- **Grounded answers:** the prompt tells the model to reply "I couldn't find that in the provided documents." when the context doesn't contain the answer, which reduces hallucination.
- **Sources shown:** every answer lists the file (and PDF page) of the chunks it was built from.
- **Observability:** set the LangSmith variables in `.env` to trace each retrieval and generation step.

## Tech stack

Python, LangChain, FAISS, Hugging Face sentence-transformers, Anthropic Claude (via `langchain-anthropic`), Streamlit, LangSmith (optional).

## Setup

```bash
git clone https://github.com/KK-007-byte/rag-document-qa.git
cd rag-document-qa
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                 # then add your ANTHROPIC_API_KEY
```

## Usage

**Command line**

```bash
python rag_pipeline.py ingest --docs docs --index index
python rag_pipeline.py ask "What is RAG and why does it reduce hallucination?"
```

**Web app**

```bash
streamlit run app.py
```

Upload PDFs or text files in the sidebar, click **Build index**, then ask questions. The "Retrieved context" panel shows the exact chunks the answer was based on. A sample document is included in `docs/` so you can try it immediately.

## Configuration

Set in `.env` (all optional):

| Variable | Default | Meaning |
|---|---|---|
| `CHUNK_SIZE` | 1000 | Characters per chunk |
| `CHUNK_OVERLAP` | 200 | Overlap between chunks |
| `TOP_K` | 4 | Chunks retrieved per question |
| `EMBEDDING_MODEL` | sentence-transformers/all-MiniLM-L6-v2 | Embedding model |
| `LLM_MODEL` | claude-sonnet-5-5 | Chat model |

## Project structure

```
rag_pipeline.py   ingestion, indexing, retrieval, answer generation, CLI
app.py            Streamlit interface
docs/             documents to index (sample included)
requirements.txt
.env.example
```

## Limitations and ideas

- Chunking is character-based; semantic or structure-aware chunking could improve retrieval on long documents.
- Retrieval is plain vector similarity; adding a reranker or hybrid keyword search would help on exact-match queries.
- Scanned PDFs need OCR before indexing.
- No automated evaluation yet; a small question/answer test set would make it possible to measure changes to chunk size or `k`.

## License

MIT
