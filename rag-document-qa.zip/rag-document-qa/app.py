"""Streamlit front end for the RAG document QA system."""
from pathlib import Path

import streamlit as st

import rag_pipeline as rag

DOCS_DIR, INDEX_DIR = "docs", "index"

st.set_page_config(page_title="RAG Document QA", page_icon="📄")
st.title("📄 RAG Document QA")
st.caption("Ask questions about your documents. Answers are grounded in retrieved text.")


@st.cache_resource(show_spinner="Loading embedding model...")
def embeddings():
    return rag.get_embeddings()


with st.sidebar:
    st.header("Documents")
    uploads = st.file_uploader("Upload PDF / TXT / MD", type=["pdf", "txt", "md"], accept_multiple_files=True)
    if st.button("Build index", disabled=not uploads):
        Path(DOCS_DIR).mkdir(exist_ok=True)
        for f in uploads:
            (Path(DOCS_DIR) / f.name).write_bytes(f.getvalue())
        with st.spinner("Indexing..."):
            rag.build_index(DOCS_DIR, INDEX_DIR, embeddings())
        st.success("Index ready.")
    top_k = st.slider("Chunks to retrieve (k)", 1, 10, rag.TOP_K)

question = st.text_input("Your question")
if question:
    if not Path(INDEX_DIR).exists():
        st.warning("Upload documents and click 'Build index' first (or run `python rag_pipeline.py ingest`).")
    else:
        store = rag.load_index(INDEX_DIR, embeddings())
        with st.spinner("Thinking..."):
            reply, docs = rag.answer(question, store, k=top_k)
        st.markdown(reply)
        with st.expander("Retrieved context"):
            for d in docs:
                st.markdown(f"**{rag.describe_source(d)}**")
                st.text(d.page_content)
