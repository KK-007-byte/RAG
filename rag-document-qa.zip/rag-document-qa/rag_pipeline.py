"""Retrieval-Augmented Generation (RAG) pipeline.

documents -> chunks -> embeddings -> FAISS index -> retrieve top-k -> grounded LLM answer

Usage:
    python rag_pipeline.py ingest --docs docs --index index
    python rag_pipeline.py ask "What is RAG?" --index index
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path

from dotenv import load_dotenv
from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_text_splitters import RecursiveCharacterTextSplitter

load_dotenv()

# --- Configuration (override with environment variables) ---------------------
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", 1000))
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", 200))
TOP_K = int(os.getenv("TOP_K", 4))
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
LLM_MODEL = os.getenv("LLM_MODEL", "claude-sonnet-5-5")

NOT_FOUND = "I couldn't find that in the provided documents."

PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You answer questions using ONLY the context below. "
            f"If the context does not contain the answer, reply exactly: {NOT_FOUND}\n\n"
            "Context:\n{context}",
        ),
        ("human", "{question}"),
    ]
)


# --- Ingestion ----------------------------------------------------------------
def load_documents(docs_dir: str | Path) -> list[Document]:
    """Load every .pdf, .txt and .md file under docs_dir."""
    docs: list[Document] = []
    for path in sorted(Path(docs_dir).rglob("*")):
        suffix = path.suffix.lower()
        if suffix == ".pdf":
            docs.extend(PyPDFLoader(str(path)).load())
        elif suffix in {".txt", ".md"}:
            docs.extend(TextLoader(str(path), encoding="utf-8").load())
    if not docs:
        raise FileNotFoundError(f"No .pdf, .txt or .md files found in '{docs_dir}'.")
    return docs


def split_documents(docs: list[Document]) -> list[Document]:
    """Split documents into overlapping chunks so each fits an embedding."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP
    )
    return splitter.split_documents(docs)


def get_embeddings():
    from langchain_huggingface import HuggingFaceEmbeddings

    return HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)


def build_index(docs_dir: str, index_dir: str, embeddings=None) -> FAISS:
    """Load, chunk, embed and save a FAISS index."""
    embeddings = embeddings or get_embeddings()
    chunks = split_documents(load_documents(docs_dir))
    store = FAISS.from_documents(chunks, embeddings)
    store.save_local(index_dir)
    print(f"Indexed {len(chunks)} chunks -> {index_dir}/")
    return store


def load_index(index_dir: str, embeddings=None) -> FAISS:
    embeddings = embeddings or get_embeddings()
    # The index is created by this app on your own machine, so loading it is safe.
    return FAISS.load_local(index_dir, embeddings, allow_dangerous_deserialization=True)


# --- Question answering ---------------------------------------------------------
def get_llm():
    from langchain_anthropic import ChatAnthropic

    return ChatAnthropic(model=LLM_MODEL, temperature=0)


def format_context(docs: list[Document]) -> str:
    return "\n\n".join(d.page_content for d in docs)


def describe_source(doc: Document) -> str:
    name = Path(doc.metadata.get("source", "unknown")).name
    page = doc.metadata.get("page")
    return f"{name} (page {page + 1})" if isinstance(page, int) else name


def answer(question: str, store: FAISS, llm=None, k: int = TOP_K) -> tuple[str, list[Document]]:
    """Retrieve the top-k chunks and ask the LLM to answer from them only."""
    docs = store.as_retriever(search_kwargs={"k": k}).invoke(question)
    chain = PROMPT | (llm or get_llm()) | StrOutputParser()
    reply = chain.invoke({"context": format_context(docs), "question": question})
    return reply, docs


# --- CLI ------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description="RAG document question answering")
    sub = parser.add_subparsers(dest="cmd", required=True)

    ing = sub.add_parser("ingest", help="build the vector index from a folder of documents")
    ing.add_argument("--docs", default="docs")
    ing.add_argument("--index", default="index")

    ask = sub.add_parser("ask", help="ask a question about the indexed documents")
    ask.add_argument("question")
    ask.add_argument("--index", default="index")
    ask.add_argument("-k", type=int, default=TOP_K)

    args = parser.parse_args()
    if args.cmd == "ingest":
        build_index(args.docs, args.index)
    else:
        reply, docs = answer(args.question, load_index(args.index), k=args.k)
        print(reply)
        print("\nSources:")
        for source in dict.fromkeys(describe_source(d) for d in docs):
            print(f"  - {source}")


if __name__ == "__main__":
    main()
